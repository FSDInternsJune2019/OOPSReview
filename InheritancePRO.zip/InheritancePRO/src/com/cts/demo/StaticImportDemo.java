package com.cts.demo;
import static java.lang.Math.*;
public class StaticImportDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double result=sin(12.5)*cos(10.2)/sqrt(4);
		

	}

}
