package com.cts.demo;

public class InnerOuterDemo {
	
	//class file name InnerOuterDemo$Inner.class
	static class Inner{
		
		public void innerMethod(){
			System.out.println("--innerMethod--");
		}
	}

	public static void main(String args[]){
		
		InnerOuterDemo outer=new InnerOuterDemo();
		InnerOuterDemo.Inner inner=outer.new Inner();
		inner.innerMethod();
		
		InnerOuterDemo.Inner innerStatic=new InnerOuterDemo.Inner();
		innerStatic.innerMethod();
		
	}
}
