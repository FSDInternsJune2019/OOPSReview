package com.cts.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.cts.entity.Employee;

public class EmployeeSortDemo {
	
	class EmployeeSortyByName implements Comparator<Employee>{

		@Override
		public int compare(Employee o1, Employee o2) {
			// TODO Auto-generated method stub
			return o1.getEmpName().compareTo(o2.getEmpName());
		}
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1=new Employee();
		e1.setEmpId(101);
		e1.setEmpName("Sabbir");
		e1.setEmpSalary(34000);
		e1.setEmpDesignation("Trainer");
		
		Employee e2=new Employee();
		e2.setEmpId(99);
		e2.setEmpName("Amit");
		e2.setEmpSalary(94000);
		e2.setEmpDesignation("Programmer");
		
		Employee e3=new Employee();
		e3.setEmpId(102);
		e3.setEmpName("Rohit");
		e3.setEmpSalary(14000);
		e3.setEmpDesignation("Developer");
		
		List<Employee> empList=new ArrayList<Employee>();
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		System.out.println("=======by id=======");
		
		Collections.sort(empList,new EmployeeSortById());
		empList.forEach((e)->{
			System.out.println(e);
			
		});
		
		empList.forEach(System.out::println);
		
		System.out.println("=========by name======");
		
		Collections.sort(empList,new EmployeeSortDemo().new EmployeeSortyByName());
		empList.forEach(System.out::println);
		
		Collections.sort(empList,
				
				new Comparator<Employee>(){
			
			@Override
			public int compare(Employee e1,Employee e2){
				
				if(e1.getEmpSalary()>e2.getEmpSalary()){
					return 1;
				}else if(e1.getEmpSalary()<e2.getEmpSalary()){
					return -1;
				}else{
					return 0;
				}
			}
			
		}
				
				);
		System.out.println("========by salary======");
		empList.forEach(System.out::println);
		
		System.out.println("======by designation=====");
		
		Collections.sort(empList,(employee1,employee2)->{
			
			return employee1.getEmpDesignation().compareTo(employee2.getEmpDesignation());
			
		});
		empList.forEach(System.out::println);

		
	}
	

}
