package com.cts.demo;

public class ComputeInterfaceImpl implements ComputeInterface {

	@Override
	public double compute(double no1, double no2) {
		// TODO Auto-generated method stub
		return no1+no2;
	}
	
	
	class ComputeInterfaceInner implements ComputeInterface{

		@Override
		public double compute(double no1, double no2) {
			// TODO Auto-generated method stub
			return no1-no2;
		}
		
		
		
	}
	
	public static void main(String args[]){
		
		ComputeInterfaceImpl outer=new ComputeInterfaceImpl();
		outer.new ComputeInterfaceInner().compute(20, 30);
		
		ComputeInterface annoy=new ComputeInterface(){
			
			@Override
			public double compute(double no1, double no2) {
				// TODO Auto-generated method stub
				return no1*no2;
			}
		};
		
		annoy.compute(45, 65);
		
		ComputeInterface lambda=(a,b)->a/b;
		System.out.println("Div:"+lambda.compute(30, 40));
		
		
		
	
	}

}
