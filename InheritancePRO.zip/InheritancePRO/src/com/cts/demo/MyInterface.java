package com.cts.demo;

public interface MyInterface {
	
	void y();
	
	

}
