package com.cts.demo;

public class BlocksDemo {
	
	private int i;
	
	private static int j;
	
	{
		System.out.println("--block1--");
		
		i=10;
	}
	{
		System.out.println("--block2--");
		i=30;
	}
	static{
		j=45;
	}
	
	
	public int getI(){
		return i;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BlocksDemo block1=new BlocksDemo();
		System.out.println("Value of i:"+block1.getI());

	}

}
