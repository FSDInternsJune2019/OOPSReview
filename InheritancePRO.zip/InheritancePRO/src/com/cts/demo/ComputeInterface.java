package com.cts.demo;

public interface ComputeInterface {
	
	double compute(double no1,double no2);

}
