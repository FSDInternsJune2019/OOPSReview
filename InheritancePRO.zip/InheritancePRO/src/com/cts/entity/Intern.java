package com.cts.entity;

public class Intern extends User{
	
	public Intern(){}
	private int internId;
	
	public Intern(String userName,String password,String firstName,String lastName,int age,String phoneNumber,String emailAddress,int internId){
		super(userName,password,firstName,lastName,age,phoneNumber,emailAddress);
		this.internId=internId;
	}

	public int getInternId() {
		return internId;
	}

	@Override
	public String toString() {
		return "Intern [internId=" + internId + "]";
	}

	
}
