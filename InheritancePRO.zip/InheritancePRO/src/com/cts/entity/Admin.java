package com.cts.entity;

public class Admin extends User{
	
	private int adminId;
	public Admin(){}
	
	public Admin(String userName,String password,String firstName,String lastName,int age,String phoneNumber,String emailAddress,int adminId){
		super(userName,password,firstName,lastName,age,phoneNumber,emailAddress);
	    this.adminId=adminId;
	}

}
